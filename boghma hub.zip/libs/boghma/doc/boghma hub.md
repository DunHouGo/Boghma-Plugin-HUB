
| boghma hub
	| Cinema4d Plugins
		| PluginA
			PA.pyp
			Info.json
		| PluginB
			PB.pyp
			Info.json
	| libs
		|boghma
			\_\_init\_\_.py
	| resource
		| PluginA
			| Metadata.json
			otherfiles..
		| PluginB
			| Metadata.json
			otherfiles..