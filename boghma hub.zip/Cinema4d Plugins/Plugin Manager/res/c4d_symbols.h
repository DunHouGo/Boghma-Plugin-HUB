enum
{
	// End of symbol definition
	_DUMMY_ELEMENT_
};